<%-- 
    Document   : ProcessAuthor
    Created on : 12 May 2026, 3:15:46 pm
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>
<%-- Step 16: Create the bean object --%>
<jsp:useBean id="myAuthor" class="lab6.com.Author" scope="request" />
<%-- Step 17: Map form data to bean properties --%>
<jsp:setProperty name="myAuthor" property="*" />

<!DOCTYPE html>
<html>
    <body>
        <h1>Lab 6 - Task 1 - Perform creating and retrieving records via JSP page</h1>

        <%
            int result;
            try {
                // Step 18: Load driver and establish connection
                Class.forName("com.mysql.jdbc.Driver");
                String myURL = "jdbc:mysql://localhost/CSA3023";
                Connection myConnection = DriverManager.getConnection(myURL, "root", "admin");

                // Step 19: Prepared Statement
                String sInsertQry = "INSERT INTO Author (authno, address, city, state, zip) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement myPS = myConnection.prepareStatement(sInsertQry);

                myPS.setString(1, myAuthor.getAuthno());
                myPS.setString(2, myAuthor.getAddress());
                myPS.setString(3, myAuthor.getCity());
                myPS.setString(4, myAuthor.getState());
                myPS.setString(5, myAuthor.getZip());

                // Step 20: Execute and Display
                result = myPS.executeUpdate();

                if (result > 0) {
                    out.println("<p>Record successfully added into Author table...!</p>");
                    out.print("<p style='color:blue'>Record with author no " + myAuthor.getAuthno() + " successfully created..!</p>");
                    
                    out.print("Details of record are;<br>");
                    out.print("<p style='color:blue'>Address : " + myAuthor.getAddress() + "</p>");
                    out.print("<p style='color:blue'>City : " + myAuthor.getCity() + "</p>");
                    out.print("<p style='color:blue'>State : " + myAuthor.getState() + "</p>");
                    out.print("<p style='color:blue'>Zip : " + myAuthor.getZip() + "</p>");
                }

                // Step 21: Close connection
                myConnection.close();

            } catch (Exception e) {
                out.println("Error: " + e.getMessage());
            }
        %>
    </body>
</html>