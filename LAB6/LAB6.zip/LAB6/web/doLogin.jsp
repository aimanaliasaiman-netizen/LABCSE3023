<%-- 
    Document   : doLogin
    Created on : 12 May 2026, 4:00:03?pm
    Author     : aiman
--%>
<%@page import="java.sql.*"%>
<%
    String user = request.getParameter("username");
    String pass = request.getParameter("password");

    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/CSA3023", "root", "admin");
        
        String sql = "SELECT * FROM userprofile WHERE BINARY username=? AND password=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, user);
        ps.setString(2, pass);
        
        ResultSet rs = ps.executeQuery();
        
        if(rs.next()) {
            // Success: Redirect to main.jsp with user details
            String url = "main.jsp?user=" + rs.getString("username") + 
                         "&fname=" + rs.getString("firstname") + 
                         "&lname=" + rs.getString("lastname");
            response.sendRedirect(url);
        } else {
            // Failure: Redirect back to login
            response.sendRedirect("login.jsp?msg=Invalid username or password..!");
        }
        con.close();
    } catch(Exception e) {
        out.print(e.getMessage());
    }
%>