<%-- 
    Document   : main
    Created on : 12 May 2026, 4:00:21?pm
    Author     : aiman
--%>
<!DOCTYPE html>
<html>
<head><title>Main Page</title></head>
<body>
    <h2>Welcome to the System</h2>
    <p><strong>Username:</strong> <%= request.getParameter("user") %></p>
    <p><strong>First Name:</strong> <%= request.getParameter("fname") %></p>
    <p><strong>Last Name:</strong> <%= request.getParameter("lname") %></p>
    <br>
    <a href="login.jsp">Logout</a>
</body>
</html>