<%-- 
    Document   : SampleInsertionRecord
    Created on : 12 May 2026, 2:04:01 pm
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>

<!DOCTYPE html>
<html>
    <head>
        <title>Lab 6 - Task 1</title>
    </head>
    <body>
        <h1>Lab 6 - Task 1 - Sample Insertion records into MySQL through JSP's page</h1>

        <%
            int result;
            Connection myConnection = null;
            PreparedStatement myPS = null;

            try {
                // Step 1: Load JDBC driver...
                Class.forName("com.mysql.jdbc.Driver");
                out.println("Step 1: MySQL driver loaded...!");
        %>
        <br>
        <%
                // Step 2: Establish the connection...
                String myURL = "jdbc:mysql://localhost/CSA3023";
                myConnection = DriverManager.getConnection(myURL, "root", "admin");
                out.println("Step 2: Database is connected...!");
        %>
        <br>
        <%
                // Step 3: Create a PreparedStatement object...
                out.println("Step 3: Prepared Statements created...!");

                // Prepared SQL Query as a String...
                String sInsertQry = "INSERT INTO FirstTable VALUE (?)";

                // Call method preparedStatement
                myPS = myConnection.prepareStatement(sInsertQry);
        %>
        <br>
        <%
                // Step 4: Perform insertion of record...!
                out.println("Step 4: Perform insertion of record...!");
                String name = "Welcome to access MySQL database with JSP!";
                myPS.setString(1, name);

                result = myPS.executeUpdate();

                if (result > 0) {
        %>
        <br>
        <%
                    // Step 5: Close database connection...!
                    out.println("Step 5: Close database connection...!");
                    out.println(" ");
                    
                    // Note: Usually connections are closed in a finally block, 
                    // but following the slide logic:
                    myConnection.close();
                    out.println("Database connection is closed...!");

                    out.print("<p>" + "The record : (" + name 
                            + ") is successfully created..!" + "</p>");
                }
            } catch (Exception e) {
                out.println("Error: " + e.getMessage());
            }
        %>
    </body>
</html>