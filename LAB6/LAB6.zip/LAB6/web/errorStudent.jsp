<%-- 
    Document   : errorStudent
    Created on : 12 May 2026, 3:47:39 pm
    Author     : aiman
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%-- Step 2: Define that this is an error page --%>
<%@page isErrorPage="true" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Error Page</title>
    </head>
    <body>
        <%-- Step 3: Complete remaining code --%>
        <form id="errorFrm" action="InsertStudent.jsp" method="post">
            <h1>Lab 9 - Task 1 - Perform creating and retrieving records via JSP page</h1>
            
            <p>An error occurred when inserting record...!</p>
            
            <p>
                <strong>Error Message: </strong>
                <jsp:expression>exception.getMessage()</jsp:expression>
            </p>
            
            <br>
            <input type="submit" value="Back to Registration">
        </form>
    </body>
</html>