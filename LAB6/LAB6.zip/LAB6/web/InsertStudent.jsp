<%-- 
    Document   : InsertStudent
    Created on : 12 May 2026, 3:45:54 pm
    Author     : aiman
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Student Registration</title>
    </head>
    <body>
        <fieldset>
            <legend>Student Registration</legend>
            <form action="ProcessStudent.jsp" method="POST">
                <table>
                    <tr>
                        <td>Student No</td>
                        <td><input type="text" name="stuno" placeholder="E.g.: UKXXXXX"></td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="name" placeholder="Enter your name"></td>
                    </tr>
                    <tr>
                        <td>Program</td>
                        <td>
                            <select name="program">
                                <option>BSc. Soft. Eng.</option>
                                <option>BSc. with IM</option>
                                <option>BSc. in Networking</option>
                                <option>BSc. in Robotics</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="submit" value="Submit">
                            <input type="reset" value="Cancel">
                        </td>
                    </tr>
                </table>
            </form>
        </fieldset>
    </body>
</html>