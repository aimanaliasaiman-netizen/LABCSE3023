<%-- 
    Document   : ProcessStudent
    Created on : 12 May 2026, 3:47:04 pm
    Author     : aiman
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>
<%@page errorPage="errorStudent.jsp" %>

<jsp:useBean id="myStudent" class="lab6.com.Student" scope="request" />
<jsp:setProperty name="myStudent" property="*"/>

<!DOCTYPE html>
<html>
    <body>
        <%
            // Validate stuno before proceeding
            if (myStudent.getStuno().equals("invalid")) {
                throw new Exception("Invalid Student ID format. Use capital letters and numbers only.");
            }

            int result;
            try {
                // Step 1: Load Driver
                Class.forName("com.mysql.jdbc.Driver");
                
                // Step 2: Connection
                String myURL = "jdbc:mysql://localhost/CSA3023";
                Connection myConnection = DriverManager.getConnection(myURL, "root", "admin");

                // Step 3: Prepared Statement
                String sInsertQry = "INSERT INTO student (stuno, stuname, stuprogram) VALUES (?, ?, ?)";
                PreparedStatement myPS = myConnection.prepareStatement(sInsertQry);

                myPS.setString(1, myStudent.getStuno());
                myPS.setString(2, myStudent.getName());
                myPS.setString(3, myStudent.getProgram());

                // Step 4: Execute
                result = myPS.executeUpdate();

                if (result > 0) {
                    out.print("<h3>Record successfully added!</h3>");
                    out.print("<p>Student ID : " + myStudent.getStuno() + "</p>");
                    out.print("<p>Name : " + myStudent.getName() + "</p>");
                    out.print("<p>Program : " + myStudent.getProgram() + "</p>");
                }

                myConnection.close();
            } catch (Exception e) {
                out.print("Error: " + e.getMessage());
            }
        %>
    </body>
</html>