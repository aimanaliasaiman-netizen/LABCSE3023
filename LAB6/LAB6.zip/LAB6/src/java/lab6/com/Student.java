package lab6.com;

import java.io.Serializable;
import java.util.regex.*;

public class Student implements Serializable {
    private String stuno;
    private String name;
    private String program;

    public Student() {}

    // Getter for stuno with Regex validation
    public String getStuno() {
        Pattern pt = Pattern.compile("[A-Z0-9]*");
        Matcher mt = pt.matcher(stuno);
        boolean bl = mt.matches();
        
        if (bl == true) {
            return stuno;
        } else {
            return "invalid";
        }
    }

    public void setStuno(String stuno) {
        this.stuno = stuno;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getProgram() { return program; }
    public void setProgram(String program) { this.program = program; }
}