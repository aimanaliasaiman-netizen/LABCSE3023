<%-- 
    Document   : greeting
    Created on : 1 Apr 2026, 11:07:04 am
    Author     : aiman
--%>

<%@page import="java.util.Date"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        //page tittle
        <title>Greeting Page</title>
        <%response.setIntHeader("Refresh", 5); %>
    </head>
    <body>
        <h1>Hello, <%= request.getAttribute("userName") %>!</h1>
        <p>The current date and time is: <%= new java.util.Date() %></p>
    </body>
</html>