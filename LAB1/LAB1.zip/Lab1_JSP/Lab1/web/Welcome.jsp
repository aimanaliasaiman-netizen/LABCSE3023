<%-- 
    Document   : Welcome
    Created on : 1 Apr 2026, 10:41:00 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>CSE3023 - WebBased Application Development</title>
    </head>
    <body>
        <h1>Welcome to CSE3023</h1>
    </body>
</html>
