<%-- 
    Document   : jspParameter
    Created on : 27 Apr 2026, 1:01:20 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Using JSP Standard Action</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <h2 class="form-title">Using jsp:include and jsp:param to display information</h2>
            
            <%
                // Define subject information
                String sCode = "CSE3023";
                String sSubject = "Web-based Application Development";
                String sCredit = "3(2+1)";
            %>
            
            <!-- JSP Standard Action: include with parameters -->
            <jsp:include page="subjectInfo.jsp">
                <jsp:param name="code" value="<%= sCode %>" />
                <jsp:param name="subject" value="<%= sSubject %>" />
                <jsp:param name="credit" value="<%= sCredit %>" />
            </jsp:include>
            
            <br>
            <a href="index.html" class="btn-back">← Back</a>
            
        </div>
    </div>
</body>
</html>