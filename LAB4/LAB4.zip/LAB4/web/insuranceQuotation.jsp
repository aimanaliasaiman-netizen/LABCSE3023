<%-- 
    Document   : insuranceQuotation
    Created on : 27 Apr 2026, 1:13:34 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h2 class="form-title">Insurance Quotation System</h2>
            <p>Please fill in your details below</p>
            
            <form action="processInsuranceQuo.jsp" method="post">
                <div class="form-group">
                    <label for="icno">IC Number:</label>
                    <input type="text" name="icno" id="icno" required placeholder="e.g., 010101-01-1234">
                </div>
                
                <div class="form-group">
                    <label for="name">Full Name:</label>
                    <input type="text" name="name" id="name" required placeholder="Enter your full name">
                </div>
                
                <div class="form-group">
                    <label>Coverage Type:</label>
                    <div class="radio-group">
                        <label class="radio-label">
                            <input type="radio" name="coverage" value="comprehensive" required> Comprehensive (5%)
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="coverage" value="thirdparty"> Third Party (3%)
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="price">Vehicle Price (RM):</label>
                    <input type="number" name="price" id="price" step="any" required placeholder="Enter vehicle price">
                </div>
                
                <div class="form-group">
                    <label for="ncd">No Claim Discount (NCD) - %:</label>
                    <select name="ncd" id="ncd" required>
                        <option value="0">0% (No discount)</option>
                        <option value="0.25">25% (1 year no claim)</option>
                        <option value="0.30">30% (2 years no claim)</option>
                        <option value="0.383">38.3% (3 years no claim)</option>
                        <option value="0.45">45% (4 years no claim)</option>
                        <option value="0.55">55% (5+ years no claim)</option>
                    </select>
                </div>
                
                <div class="button-group">
                    <input type="submit" value="Calculate Quotation" class="btn btn-submit">
                    <input type="reset" value="Clear" class="btn btn-cancel">
                </div>
            </form>
        </div>
    </div>
</body>
</html>