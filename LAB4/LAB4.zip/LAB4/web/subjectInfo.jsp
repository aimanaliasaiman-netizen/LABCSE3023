<%-- 
    Document   : subjectInfo
    Created on : 27 Apr 2026, 1:03:04 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Subject Information</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="result-box">
        <h3>Subject Details</h3>
        
        <div class="result-group">
            <label>Code:</label>
            <p><%= request.getParameter("code") %></p>
        </div>
        
        <div class="result-group">
            <label>Subject:</label>
            <p><%= request.getParameter("subject") %></p>
        </div>
        
        <div class="result-group">
            <label>Credit Hours:</label>
            <p><%= request.getParameter("credit") %></p>
        </div>
    </div>
</body>
</html>