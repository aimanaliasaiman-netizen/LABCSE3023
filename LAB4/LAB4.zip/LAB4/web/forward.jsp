<%-- 
    Document   : forward
    Created on : 27 Apr 2026, 1:10:52 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Using JSP Standard Action (Forward)</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <h2 class="form-title">Using jsp:forward to display user information</h2>
            
            <p>Redirecting to forwardInfo.jsp...</p>
            
            <!-- JSP Standard Action: forward with parameters -->
            <jsp:forward page="forwardInfo.jsp">
                <jsp:param name="uname" value="Wan Nural Jawahir Hj Wan Yussof" />
                <jsp:param name="email" value="wannurwy@umt.edu.my" />
                <jsp:param name="nationality" value="Malaysia" />
                <jsp:param name="background" value="Lecturer" />
            </jsp:forward>
            
        </div>
    </div>
</body>
</html>