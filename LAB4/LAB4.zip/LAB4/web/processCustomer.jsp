<%-- 
    Document   : processCustomer
    Created on : 26 Apr 2026, 11:26:17 pm
    Author     : aiman
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Customer Processing</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <%
                // Fixed price
                final double price = 10.0;
                
                // Retrieve form data
                String cust_no = request.getParameter("customerCode");
                String cust_type = request.getParameter("customerType");
                int quantity = 0;
                
                try {
                    quantity = Integer.parseInt(request.getParameter("quantity"));
                } catch (Exception e) {
                    quantity = 0;
                }
                
                // Business logic
                double total = 0;
                String message = "";
                
                if (cust_type.equals("1") && quantity > 100) {
                    message = "You're entitled to 10% discount";
                    total = quantity * price * 0.9;
                } else if (cust_type.equals("2") && quantity > 100) {
                    message = "You're entitled to 25% discount";
                    total = quantity * price * 0.75;
                } else {
                    message = "You're not entitled to any discount";
                    total = quantity * price;
                }
                
                // Display customer type
                String custTypeDisplay = cust_type.equals("1") ? "Normal Customer" : "Privilege Customer";
            %>
            
            <h1>Customer Processing Result</h1>
            
            <p><strong>Customer Code:</strong> <%= cust_no %></p>
            <p><strong>Customer Type:</strong> <%= custTypeDisplay %></p>
            <p><strong>Quantity:</strong> <%= quantity %></p>
            <p><strong>Price per unit:</strong> RM <%= price %></p>
            <p><strong><%= message %></strong></p>
            <p><strong>Total Amount:</strong> RM <%= total %></p>
            

            <div style="text-align: left; margin-top: 25px;">
                <a href="customer.html" class="btn-back">Back</a>
            </div>
            
        </div>
    </div>
</body>
</html>