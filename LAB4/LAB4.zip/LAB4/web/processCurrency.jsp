<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Currency Conversion Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <%!
                // DECLARATION - Exchange rates
                final double USD = 0.25;
                final double EURO = 0.21;
                final double JPY = 40.0;
                final double SGD = 0.32;
                
                private double calculateRate(String currency, int amount) {
                    double currencyChange = 0.0;
                    if (currency != null) {
                        if (currency.equals("1")) {
                            currencyChange = amount * USD;
                        } else if (currency.equals("2")) {
                            currencyChange = amount * EURO;
                        } else if (currency.equals("3")) {
                            currencyChange = amount * JPY;
                        } else {
                            currencyChange = amount * SGD;
                        }
                    }
                    return currencyChange;
                }
            %>
            
            <%
                // SCRIPTLET - Retrieve and process
                String currencyType = request.getParameter("currencyType");
                String amountRaw = request.getParameter("amount");
                int amount = 0;
                double total = 0;
                
                try {
                    if (amountRaw != null && !amountRaw.isEmpty()) {
                        amount = Integer.parseInt(amountRaw);
                        total = calculateRate(currencyType, amount);
                    }
                } catch (Exception e) {
                    amount = 0;
                    total = 0;
                }
                
                String currencyName = "N/A";
                if ("1".equals(currencyType)) {
                    currencyName = "USD";
                } else if ("2".equals(currencyType)) {
                    currencyName = "EURO";
                } else if ("3".equals(currencyType)) {
                    currencyName = "JPY";
                } else if ("4".equals(currencyType)) {
                    currencyName = "SGD";
                }
            %>
            
            <h2>Currency Conversion Result</h2>
            <label>Amount in Ringgit Malaysia (RM):</label>
            <p>RM <%= amount %></p>
            
            <label>Converted to (<%= currencyName %>):</label>
            <p><%= String.format("%.2f", total) %></p>
            
            <br>
            <a href="currencyConversion.html">Back</a>
            
        </div>
    </div>
</body>
</html>