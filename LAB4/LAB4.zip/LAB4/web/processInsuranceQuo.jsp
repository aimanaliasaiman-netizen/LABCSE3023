<%-- 
    Document   : processInsuranceQuo
    Created on : 27 Apr 2026, 1:15:03 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <%
                // ============================================
                // JSP SCRIPTLET - Business Logic for Insurance
                // ============================================
                
                // Retrieve form data
                String icno = request.getParameter("icno");
                String name = request.getParameter("name");
                String coverage = request.getParameter("coverage");
                String ncdStr = request.getParameter("ncd");
                
                double price = 0;
                double ncd = 0;
                
                try {
                    price = Double.parseDouble(request.getParameter("price"));
                    ncd = Double.parseDouble(ncdStr);
                } catch (Exception e) {
                    price = 0;
                    ncd = 0;
                }
                
                // Business Logic for Insurance Rate
                double rate = 0;
                String coverageDisplay = "";
                
                if ("comprehensive".equals(coverage)) {
                    rate = 0.05;    // 5% for comprehensive
                    coverageDisplay = "Comprehensive (5%)";
                } else {
                    rate = 0.03;    // 3% for third party
                    coverageDisplay = "Third Party (3%)";
                }
                
                // Base insurance calculation
                double insurance = price * rate;
                
                // Apply NCD discount
                double discount = insurance * ncd;
                double afterNCD = insurance - discount;
                
                // Add 8% SST (Sales and Service Tax)
                double sst = afterNCD * 0.08;
                double finalAmount = afterNCD + sst;
            %>
            
            <h2 class="form-title">Insurance Quotation Result</h2>
            
            <div class="result-grid">
                <!-- Customer Information -->
                <div class="result-box">
                    <h3>Customer Information</h3>
                    <div class="result-group">
                        <label>IC Number:</label>
                        <p><%= icno %></p>
                    </div>
                    <div class="result-group">
                        <label>Full Name:</label>
                        <p><%= name %></p>
                    </div>
                    <div class="result-group">
                        <label>Vehicle Price:</label>
                        <p>RM <%= String.format("%.2f", price) %></p>
                    </div>
                </div>
                
                <!-- Insurance Calculation -->
                <div class="result-box">
                    <h3>Insurance Calculation</h3>
                    <div class="result-group">
                        <label>Coverage Type:</label>
                        <p><%= coverageDisplay %></p>
                    </div>
                    <div class="result-group">
                        <label>Insurance Rate:</label>
                        <p><%= (int)(rate * 100) %>%</p>
                    </div>
                    <div class="result-group">
                        <label>Base Insurance:</label>
                        <p>RM <%= String.format("%.2f", insurance) %></p>
                    </div>
                </div>
                
                <!-- Discount & Tax -->
                <div class="result-box">
                    <h3>Discount & Tax</h3>
                    <div class="result-group">
                        <label>NCD Applied:</label>
                        <p><%= (int)(ncd * 100) %>%</p>
                    </div>
                    <div class="result-group">
                        <label>NCD Discount:</label>
                        <p>- RM <%= String.format("%.2f", discount) %></p>
                    </div>
                    <div class="result-group">
                        <label>SST (8%):</label>
                        <p>+ RM <%= String.format("%.2f", sst) %></p>
                    </div>
                </div>
                
                <!-- Final Amount -->
                <div class="result-box">
                    <h3>Total Premium</h3>
                    <div class="result-group">
                        <label>After NCD:</label>
                        <p>RM <%= String.format("%.2f", afterNCD) %></p>
                    </div>
                    <div class="result-group">
                        <label>After SST (8%):</label>
                        <p><strong>RM <%= String.format("%.2f", finalAmount) %></strong></p>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background-color: #d4edda; border-radius: 8px; text-align: center;">
                <p style="color: #155724; font-weight: bold;">Thank you for using our Insurance Quotation System!</p>
                <p style="color: #155724;">This quotation is valid for 30 days.</p>
            </div>
            
            <div style="text-align: center; margin-top: 20px;">
                <a href="insuranceQuotation.jsp" class="btn-back">← New Quotation</a>
            </div>
            
        </div>
    </div>
</body>
</html>