<%-- 
    Document   : forwardInfo
    Created on : 27 Apr 2026, 1:11:32 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Forwarded Information</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <h2 class="form-title">User Information (Forwarded Data)</h2>
            
            <%
                // Retrieve forwarded parameters
                String name = request.getParameter("uname");
                String email = request.getParameter("email");
                String nationality = request.getParameter("nationality");
                String background = request.getParameter("background");
            %>
            
            <div class="result-box">
                <h3>User Details</h3>
                
                <div class="result-group">
                    <label>Name:</label>
                    <p><%= name %></p>
                </div>
                
                <div class="result-group">
                    <label>Email:</label>
                    <p><%= email %></p>
                </div>
                
                <div class="result-group">
                    <label>Nationality:</label>
                    <p><%= nationality %></p>
                </div>
                
                <div class="result-group">
                    <label>Background:</label>
                    <p><%= background %></p>
                </div>
            </div>
            
            <br>
            <a href="javascript:history.back()" class="btn-back">← Back</a>
            
        </div>
    </div>
</body>
</html>