<%-- 
    Document   : footer
    Created on : 27 Apr 2026, 1:27:41?am
    Author     : aiman
--%>
        </div>
        <div class="footer">
            <p>&copy; 2026 BMI Calculator System | Faculty of Computer Science and Mathematics, UMT</p>
        </div>
    </div>
</body>
</html>