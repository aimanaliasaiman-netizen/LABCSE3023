<%-- 
    Document   : bmiCalculator
    Created on : 27 Apr 2026, 1:28:03?am
    Author     : aiman
--%>

<%@include file="header.jsp" %>

<h2 class="form-title">BMI Calculator</h2>
<p>Enter your weight and height to calculate your Body Mass Index (BMI)</p>

<form action="processBMI.jsp" method="post">
    <div class="form-group">
        <label for="weight">Weight (kg):</label>
        <input type="number" name="weight" id="weight" step="any" required placeholder="e.g., 65.5">
    </div>
    
    <div class="form-group">
        <label for="height">Height (m):</label>
        <input type="number" name="height" id="height" step="any" required placeholder="e.g., 1.75">
        <small>Note: Height must be greater than 0</small>
    </div>
    
    <div class="button-group">
        <input type="submit" value="Calculate BMI" class="btn btn-submit">
        <input type="reset" value="Clear" class="btn btn-cancel">
    </div>
</form>

<%@include file="footer.jsp" %>