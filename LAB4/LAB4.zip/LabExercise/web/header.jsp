<%-- 
    Document   : header
    Created on : 27 Apr 2026, 1:27:21 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BMI Calculator System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>BMI Calculator System</h1>
            <p>Faculty of Computer Science and Mathematics, UMT</p>
        </div>
        <div class="nav">
            <a href="bmiCalculator.jsp">BMI Calculator</a>
            <a href="healthInfo.jsp">Health Information</a>
        </div>
        <div class="content">