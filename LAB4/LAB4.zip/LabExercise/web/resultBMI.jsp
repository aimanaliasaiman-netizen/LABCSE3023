<%-- 
    Document   : resultBMI
    Created on : 27 Apr 2026, 1:28:35 am
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BMI Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            
            <h2 class="form-title">BMI Calculation Result</h2>
            
            <%
                // Retrieve forwarded parameters
                String bmiStr = request.getParameter("bmi");
                String category = request.getParameter("category");
                String weightStr = request.getParameter("weight");
                String heightStr = request.getParameter("height");
                
                double bmi = 0;
                double weight = 0;
                double height = 0;
                
                try {
                    bmi = Double.parseDouble(bmiStr);
                    weight = Double.parseDouble(weightStr);
                    height = Double.parseDouble(heightStr);
                } catch (Exception e) {
                    // Handle error
                }
            %>
            
            <div class="result-box">
                <h3>Your Information</h3>
                
                <div class="result-group">
                    <label>Weight:</label>
                    <p><%= String.format("%.2f", weight) %> kg</p>
                </div>
                
                <div class="result-group">
                    <label>Height:</label>
                    <p><%= String.format("%.2f", height) %> m</p>
                </div>
                
                <div class="result-group">
                    <label>Your BMI:</label>
                    <p><strong><%= bmiStr %></strong></p>
                </div>
                
                <div class="result-group">
                    <label>BMI Category:</label>
                    <p><strong><%= category %></strong></p>
                </div>
            </div>
            
            <%
                // Display additional health information based on category
                if (category.equals("Underweight")) {
            %>
                <div class="info-box" style="background-color: #fff3cd; border-left: 4px solid #ffc107;">
                    <p><strong>Health Tip:</strong> You are underweight. Consider consulting a nutritionist for a balanced diet plan.</p>
                </div>
            <%
                } else if (category.equals("Normal")) {
            %>
                <div class="info-box" style="background-color: #d4edda; border-left: 4px solid #28a745;">
                    <p><strong>Health Tip:</strong> You have a normal BMI. Maintain your healthy lifestyle!</p>
                </div>
            <%
                } else {
            %>
                <div class="info-box" style="background-color: #f8d7da; border-left: 4px solid #dc3545;">
                    <p><strong>Health Tip:</strong> You are overweight. Regular exercise and a balanced diet can help.</p>
                </div>
            <%
                }
            %>
            
            <div style="text-align: center; margin-top: 20px;">
                <a href="bmiCalculator.jsp" class="btn-back">Calculate Again</a>
            </div>
            
        </div>
    </div>
</body>
</html>