<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Processing BMI</title>
</head>
<body>

<%
    // Retrieve form data
    String weightStr = request.getParameter("weight");
    String heightStr = request.getParameter("height");
    
    double weight = 0;
    double height = 0;
    double bmi = 0;
    String category = "";
    boolean valid = true;
    String errorMessage = "";
    
    // Validation and calculation
    try {
        weight = Double.parseDouble(weightStr);
        height = Double.parseDouble(heightStr);
        
        if (height <= 0) {
            valid = false;
            errorMessage = "Height must be greater than 0";
        } else if (weight <= 0) {
            valid = false;
            errorMessage = "Weight must be greater than 0";
        } else {
            // Calculate BMI = weight / (height * height)
            bmi = weight / (height * height);
            
            // Determine BMI category
            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi <= 25) {
                category = "Normal";
            } else {
                category = "Overweight";
            }
        }
    } catch (Exception e) {
        valid = false;
        errorMessage = "Please enter valid numeric values";
    }
    
    if (valid) {
        // Forward to result page with parameters
%>
        <jsp:forward page="resultBMI.jsp">
            <jsp:param name="bmi" value='<%= String.format("%.2f", bmi) %>' />
            <jsp:param name="category" value="<%= category %>" />
            <jsp:param name="weight" value="<%= weight %>" />
            <jsp:param name="height" value="<%= height %>" />
        </jsp:forward>
<%
    } else {
        // Forward to calculator with error message
%>
        <jsp:forward page="bmiCalculator.jsp">
            <jsp:param name="error" value="<%= errorMessage %>" />
        </jsp:forward>
<%
    }
%>

</body>
</html>