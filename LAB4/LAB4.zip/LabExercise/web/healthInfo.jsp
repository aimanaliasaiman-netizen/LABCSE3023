<%-- 
    Document   : healthInfo
    Created on : 27 Apr 2026, 1:28:45?am
    Author     : aiman
--%>

<%@page import="java.util.ArrayList" %>
<%@page import="java.util.HashMap" %>
<%@include file="header.jsp" %>

<h2 class="form-title">BMI Health Information</h2>

<%
    // Using JSP Page Directive to import Java classes (already done above)
    // Store BMI categories using ArrayList
    
    ArrayList<HashMap<String, String>> bmiCategories = new ArrayList<HashMap<String, String>>();
    
    // Add BMI categories with description
    HashMap<String, String> underweight = new HashMap<String, String>();
    underweight.put("category", "Underweight");
    underweight.put("range", "Less than 18.5");
    underweight.put("description", "You may need to gain weight. Consult a healthcare provider.");
    bmiCategories.add(underweight);
    
    HashMap<String, String> normal = new HashMap<String, String>();
    normal.put("category", "Normal");
    normal.put("range", "18.5 - 25.0");
    normal.put("description", "Healthy weight range. Keep up the good work!");
    bmiCategories.add(normal);
    
    HashMap<String, String> overweight = new HashMap<String, String>();
    overweight.put("category", "Overweight");
    overweight.put("range", "Greater than 25.0");
    overweight.put("description", "You may be at risk for health issues. Consider lifestyle changes.");
    bmiCategories.add(overweight);
%>

<p>Total BMI Categories: <strong><%= bmiCategories.size() %></strong></p>

<table border="1" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
    <thead>
        <tr style="background-color: #6f42c1; color: white;">
            <th style="padding: 12px;">No.</th>
            <th style="padding: 12px;">BMI Category</th>
            <th style="padding: 12px;">BMI Range</th>
            <th style="padding: 12px;">Health Description</th>
        </tr>
    </thead>
    <tbody>
        <%
            for (int i = 0; i < bmiCategories.size(); i++) {
                HashMap<String, String> category = bmiCategories.get(i);
                String rowClass = (i % 2 == 0) ? "style='background-color: #f9f9fb;'" : "";
        %>
            <tr <%= rowClass %>>
                <td style="padding: 10px; text-align: center;"><%= i + 1 %></td>
                <td style="padding: 10px;"><%= category.get("category") %></td>
                <td style="padding: 10px;"><%= category.get("range") %></td>
                <td style="padding: 10px;"><%= category.get("description") %></td>
            </tr>
        <%
            }
        %>
    </tbody>
</table>

<br>
<a href="bmiCalculator.jsp" class="btn-back">Go to BMI Calculator</a>

<%@include file="footer.jsp" %>