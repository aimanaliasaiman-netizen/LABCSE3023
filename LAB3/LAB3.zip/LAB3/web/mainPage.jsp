<%-- 
    Document   : mainPage
    Created on : 14 Apr 2026, 4:29:51 pm
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <header style="background:peachpuff; ">ABC Sdn Bhd</header>
        <h1>Using JSP Include Directive</h1>
        <h4 style="color:red">JSP is a technological for controllling </h4>

    </body>
    <footer>
    <%@includefile="footerPage.jsp"%>
    </footer>
</html>
