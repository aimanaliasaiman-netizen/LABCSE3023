<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Process Car Loan</title>
    </head>
    <body>
        <fieldset>
        
            <h2 style="color:blue">Details of Car Loan</h2>
            <%
                String loanAmount = request.getParameter("loanamt");
                String period = request.getParameter("period");
                double result = 0;
                
                if (loanAmount != null && period != null) {
                    double amount = Double.parseDouble(loanAmount);
                    int years = Integer.parseInt(period);
                    
                    switch(years) {
                        case 3: result = amount * 1.06; break;
                        case 4: result = amount * 1.07; break;
                        case 5: result = amount * 1.08; break;
                        case 7: result = amount * 1.09; break;
                        case 9: result = amount * 1.10; break;
                        default: result = amount * 1.08;
                    }
                }
            %>
            Loan Request : <%= loanAmount %><br>
            Period of payment = <%= period %><br>
            Total Loan = <%= result %>

    </fieldset>
    </body>
</html>