<%-- 
    Document   : populateArray
    Created on : 14 Apr 2026, 3:00:35 pm
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>TABLE</title>
    </head>
    <body>
        <h1>Read Java array and populate it into HTML table</h1>
    <center>
        <table bgcolor="blue" >
  <tr>
    <th>Salesman</th>
    <th>JAN</th>
    <th>FEB</th>
    <th>MAR</th>
  </tr>
  <tr>
    <td>Alfreds</td>
    <td>2500</td>
    <td>2100</td>
    <td>2200</td>
  </tr>
  <tr>
    <td>Mariah</td>
    <td>2000</td>
    <td>1900</td>
    <td>2400</td>
  </tr>
  <tr>
    <td>Fred</td>
    <td>1800</td>
    <td>2200</td>
    <td>2450</td>
  </tr>
</table>
    </center>
    </body>
    </form>

    &copy;2026-Syafiq
</html>
