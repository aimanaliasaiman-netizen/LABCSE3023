<%-- 
    Document   : footerPage
    Created on : 14 Apr 2026, 4:45:12 pm
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <style>
        body {
            background-color: peachpuff;
            padding:15px;
        }
    </style>
    <body>
        <h3>&copy;2026 Capik</h3>
    </body>
</html>
