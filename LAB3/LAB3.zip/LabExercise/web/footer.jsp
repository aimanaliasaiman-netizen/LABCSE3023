<%-- 
    Document   : footer
    Created on : 26 Apr 2026, 9:38:14?pm
    Author     : aiman
--%>
</div>
<div class="footer" style="background-color: #2c3e50; color: white; text-align: center; padding: 15px; margin-top: 20px;">
    <p>&copy; 2026 Student Club Registration System | Faculty of Computer Science and Mathematics, UMT</p>
    <p>All rights reserved.</p>
</div>
</body>
</html>