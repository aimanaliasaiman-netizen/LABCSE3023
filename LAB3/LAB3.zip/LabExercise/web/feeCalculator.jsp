<%-- 
    Document   : feeCalculator
    Created on : 26 Apr 2026, 9:38:49?pm
    Author     : aiman
--%>
<%@include file="header.jsp" %>

<h2>Membership Fee Calculator</h2>

<%
    String resultMessage = "";
    String totalFeeFormatted = "";
    String activitiesJoined = "";
    boolean hasCalculated = false;
    
    // Check if form has been submitted
    String numActivities = request.getParameter("numActivities");
    
    if (numActivities != null && !numActivities.trim().isEmpty()) {
        hasCalculated = true;
        activitiesJoined = numActivities;
        
        try {
            int numberOfActivities = Integer.parseInt(numActivities);
            int costPerActivity = 10;
            int totalFee = numberOfActivities * costPerActivity;
            
            // Format to 2 decimal places
            totalFeeFormatted = String.format("%.2f", (double) totalFee);
            resultMessage = "Total membership fee: RM " + totalFeeFormatted;
            
        } catch (NumberFormatException e) {
            resultMessage = "Error: Please enter a valid number.";
            hasCalculated = false;
        }
    }
%>

<form action="feeCalculator.jsp" method="post" style="width: 50%; margin: 0 auto;">
    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 10px;"><label for="numActivities">Number of Activities Joined:</label></td>
            <td style="padding: 10px;">
                <input type="number" name="numActivities" id="numActivities" min="0" step="1" required 
                       value="<%= hasCalculated ? activitiesJoined : "" %>" 
                       style="width: 100%; padding: 8px;">
            </td>
        </tr>
        <tr>
            <td style="padding: 10px;"><label>Cost per Activity:</label></td>
            <td style="padding: 10px;">RM 10.00</td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center; padding: 20px;">
                <input type="submit" value="Calculate Fee" style="background-color: #1abc9c; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">
            </td>
        </tr>
    </table>
</form>

<% if (hasCalculated) { %>
    <div style="width: 50%; margin: 20px auto; padding: 15px; background-color: #d5f5e3; border: 1px solid #27ae60; border-radius: 5px; text-align: center;">
        <h3 style="color: #27ae60;">Calculation Result</h3>
        <p style="font-size: 1.2em;"><%= resultMessage %></p>
        <p>Thank you for joining our activities!</p>
    </div>
<% } %>

<%@include file="footer.jsp" %>