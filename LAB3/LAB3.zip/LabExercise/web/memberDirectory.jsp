<%-- 
    Document   : memberDirectory
    Created on : 26 Apr 2026, 9:39:19?pm
    Author     : aiman
--%>
<%@page import="java.util.ArrayList" %>
<%@include file="header.jsp" %>

<h2>Club Member Directory</h2>
<h3>Committee Members List</h3>

<%
    // Create ArrayList to store committee member names
    ArrayList<String> committeeMembers = new ArrayList<String>();
    
    // Add at least five committee member names
    committeeMembers.add(0, "Dr. Wan Nural Jawahir - Faculty Advisor");
    committeeMembers.add(1, "Safirul - Public Relations");
    committeeMembers.add(2, "Hasan - Vice President");
    committeeMembers.add(3, "Mahmudi - Secretary");
    committeeMembers.add(4, "Amar - Treasurer");
%>

<p>The number of committee members: <strong><%= committeeMembers.size() %></strong></p>

<table border="1" style="width: 60%; margin: 20px auto; border-collapse: collapse;">
    <thead>
        <tr style="background-color: #2c3e50; color: white;">
            <th style="padding: 12px;">No.</th>
            <th style="padding: 12px;">Committee Member Name & Position</th>
        </tr>
    </thead>
    <tbody>
        <%
            // Dynamically display the names in an HTML table
            for (int i = 0; i < committeeMembers.size(); i++) {
                String rowClass = (i % 2 == 0) ? "style='background-color: #ecf0f1;'" : "";
        %>
            <tr <%= rowClass %>>
                <td style="padding: 10px; text-align: center;"><%= i + 1 %></td>
                <td style="padding: 10px;"><%= committeeMembers.get(i) %></td>
            </tr>
        <%
            }
        %>
    </tbody>
</table>

<p style="text-align: center; color: #7f8c8d;">* Please contact any committee member for more information about club activities.</p>

<%@include file="footer.jsp" %>