<%-- 
    Document   : header
    Created on : 26 Apr 2026, 9:38:03 pm
    Author     : aiman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Student Club Registration System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .nav {
            background-color: #34495e;
            overflow: hidden;
        }
        .nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .nav a:hover {
            background-color: #1abc9c;
            color: white;
        }
        .container {
            padding: 20px;
            min-height: 400px;
        }
    </style>
</head>
<body>
<div class="header">
    <h1>Student Club Registration System</h1>
    <p>Faculty of Computer Science and Mathematics, UMT</p>
</div>
<div class="nav">
    <a href="registerClub.jsp">Registration</a>
    <a href="feeCalculator.jsp">Fee Calculator</a>
    <a href="memberDirectory.jsp">Club Member Directory</a>
</div>
<div class="container">