<%-- 
    Document   : processRegistration
    Created on : 26 Apr 2026, 9:46:01?pm
    Author     : aiman
--%>
<%@include file="header.jsp" %>

<%
    // Retrieve data from the registration form using request.getParameter()
    String studentName = request.getParameter("studentName");
    String matricNo = request.getParameter("matricNo");
    String selectedClub = request.getParameter("selectedClub");
    
    // Handle null or empty values
    if (studentName == null || studentName.trim().isEmpty()) {
        studentName = "Not provided";
    }
    if (matricNo == null || matricNo.trim().isEmpty()) {
        matricNo = "Not provided";
    }
    if (selectedClub == null || selectedClub.trim().isEmpty()) {
        selectedClub = "Not selected";
    }
%>

<h2>Registration Confirmation</h2>

<fieldset style="width: 50%; margin: 0 auto; border: 2px solid #2c3e50; border-radius: 10px; padding: 20px;">
    <legend style="font-size: 1.2em; font-weight: bold; color: #2c3e50;">Registration Details</legend>
    
    <p>Thank you for registering in the Student Club Recruitment Week!</p>
    <p>Here are your registration details:</p>
    
    <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
        <tr style="background-color: #ecf0f1;">
            <td style="padding: 10px; font-weight: bold;">Student Name:</td>
            <td style="padding: 10px;"><%= studentName %></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Matric Number:</td>
            <td style="padding: 10px;"><%= matricNo %></td>
        </tr>
        <tr style="background-color: #ecf0f1;">
            <td style="padding: 10px; font-weight: bold;">Selected Club:</td>
            <td style="padding: 10px;"><%= selectedClub %></td>
        </tr>
    </table>
    
    <p style="margin-top: 20px; color: green;">You have successfully registered! Please proceed to the fee calculator to complete your membership.</p>
    
    <div style="text-align: center; margin-top: 20px;">
        <a href="feeCalculator.jsp" style="background-color: #1abc9c; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Calculate Membership Fee</a>
    </div>
</fieldset>

<%@include file="footer.jsp" %>