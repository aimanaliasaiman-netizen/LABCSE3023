<%-- 
    Document   : registerClub
    Created on : 26 Apr 2026, 9:38:25?pm
    Author     : aiman
--%>
<%@include file="header.jsp" %>

<h2>Student Club Registration Form</h2>

<form action="processRegistration.jsp" method="post" style="width: 50%; margin: 0 auto;">
    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 10px;"><label for="studentName">Student Name:</label></td>
            <td style="padding: 10px;"><input type="text" name="studentName" id="studentName" required style="width: 100%; padding: 8px;"></td>
        </tr>
        <tr>
            <td style="padding: 10px;"><label for="matricNo">Matric Number:</label></td>
            <td style="padding: 10px;"><input type="text" name="matricNo" id="matricNo" required style="width: 100%; padding: 8px;"></td>
        </tr>
        <tr>
            <td style="padding: 10px;"><label for="selectedClub">Select Club:</label></td>
            <td style="padding: 10px;">
                <select name="selectedClub" id="selectedClub" required style="width: 100%; padding: 8px;">
                    <option value="">-- Please select a club --</option>
                    <option value="Computer Science Club">Computer Science Club</option>
                    <option value="Mathematics Society">Mathematics Society</option>
                    <option value="Robotics Club">Robotics Club</option>
                    <option value="Cybersecurity Club">Cybersecurity Club</option>
                    <option value="AI and Data Science Club">AI and Data Science Club</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center; padding: 20px;">
                <input type="submit" value="Register Now" style="background-color: #1abc9c; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">
                <input type="reset" value="Clear Form" style="background-color: #e74c3c; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">
            </td>
        </tr>
    </table>
</form>

<%@include file="footer.jsp" %>