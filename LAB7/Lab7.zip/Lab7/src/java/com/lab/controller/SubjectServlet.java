package com.lab.controller;

import com.lab.bean.StudentBean;
import com.lab.bean.SubjectBean;
import com.lab.dao.SubjectDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class SubjectServlet extends HttpServlet {
    private final SubjectDAO subjectDAO = new SubjectDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.html");
            return;
        }
        
        StudentBean loggedUser = (StudentBean) session.getAttribute("loggedUser");
        String action = request.getParameter("action");

        if ("insert".equals(action)) {
            SubjectBean subject = new SubjectBean();
            subject.setMatricNo(loggedUser.getMatricNo());
            subject.setSubjectCode(request.getParameter("subjectCode"));
            subject.setSubjectName(request.getParameter("subjectName"));
            
            subjectDAO.addSubject(subject);
            response.sendRedirect("viewSubjects.jsp");
            
        } else if ("update".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            SubjectBean subject = new SubjectBean();
            subject.setId(id);
            subject.setSubjectCode(request.getParameter("subjectCode"));
            subject.setSubjectName(request.getParameter("subjectName"));
            
            subjectDAO.updateSubject(subject);
            response.sendRedirect("viewSubjects.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            subjectDAO.deleteSubject(id);
            response.sendRedirect("viewSubjects.jsp");
            
        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            SubjectBean subject = subjectDAO.getSubjectById(id);
            request.setAttribute("subjectToEdit", subject);
            request.getRequestDispatcher("updateSubject.jsp").forward(request, response);
        }
    }
}